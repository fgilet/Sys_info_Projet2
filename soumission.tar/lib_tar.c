#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "lib_tar.h"

//faut looper dans l'autre sens

unsigned int baseEightToTen(char *a) {
	int size = 0;
	while(a[size] != '\0') size++;
	unsigned int retVal = a[size - 1] - 48;
	int val = 8;
	for(int i = size - 2; i >= 0; i--) {
		retVal = retVal + ((a[i] - 48) * val); 
		val = val * 8;
	}
	return retVal;
}

/**
 * Checks whether the archive is valid.
 *
 * Each non-null header of a valid archive has:
 *  - a magic value of "ustar" and a null,
 *  - a version value of "00" and no null,
 *  - a correct checksum
 *
 * @param tar_fd A file descriptor pointing to the start of a file supposed to contain a tar archive.
 *
 * @return a zero or positive value if the archive is valid, representing the number of headers in the archive,
 *         -1 if the archive contains a header with an invalid magic value,
 *         -2 if the archive contains a header with an invalid version value,
 *         -3 if the archive contains a header with an invalid checksum value
 */
int check_archive(int tar_fd) {

	int number_of_headers = 0;
	char buf[512];
	
	read(tar_fd, (void *) buf, 512);
	
	while(buf[0] != '\0') {
		
		number_of_headers++;
		
		for(int i = 0; i < 6; i++) {
			if(buf[257+i] != TMAGIC[i]) return -1;
		}
		
		for(int i = 0; i < 2; i++) {
			if(buf[263+i] != TVERSION[i]) return -2;
		}
	
		//computing checksum
		unsigned int computed_checksum = 0;
		int space = (int) ' ';
		for(int i = 0; i < 512; i++) {
			
			if(i >= 148 && i < 156) {
				computed_checksum = computed_checksum + space;
			}
			else computed_checksum = computed_checksum + buf[i]; 
		}
		
		//reading checksum
		char readchecksum[9];
		for(int i = 0; i < 8; i++) {
			readchecksum[i] = buf[148+i];
		}
		readchecksum[8] = '\0';
			
		//comparing checksums
		unsigned int rchsm = baseEightToTen(readchecksum);
		if(computed_checksum != rchsm) return -3;
		
		char size[13];
		for(int i = 0; i < 12; i++) {
			size[i] = buf[124 + i];
		}
		size[12] = '\0';
		int s = baseEightToTen(size);
		if(s != 0) {
			int skip = (s - (s%512)) / 512;
			if(s%512 != 0) skip++;
			lseek(tar_fd, 512 * skip, SEEK_CUR); 
		}
		read(tar_fd, (void *) buf, 512);
	}
	return number_of_headers;
}

/**
 * Checks whether an entry exists in the archive.
 *
 * @param tar_fd A file descriptor pointing to the start of a tar archive file.
 * @param path A path to an entry in the archive.
 *
 * @return zero if no entry at the given path exists in the archive,
 *         any other value otherwise.
 */
int exists(int tar_fd, char *path) {
    return 0;
}

/**
 * Checks whether an entry exists in the archive and is a directory.
 *
 * @param tar_fd A file descriptor pointing to the start of a tar archive file.
 * @param path A path to an entry in the archive.
 *
 * @return zero if no entry at the given path exists in the archive or the entry is not a directory,
 *         any other value otherwise.
 */
int is_dir(int tar_fd, char *path) {

	char buf[512];
	read(tar_fd, (void *) buf, 512);
	
	while(buf[0] != '\0') {
		if(buf[156] == '5') {			
			int i = 0;
			int same_name = 1;
			while(path[i] != '\0') {
				if(path[i] != buf[i]) same_name = 0;
				i++;
			}
			if(buf[i] != '\0') same_name = 0;
			if(same_name == 1) return 1;
		}
		
		char size[13];
		for(int i = 0; i < 12; i++) {
			size[i] = buf[124 + i];
		}
		size[12] = '\0';
		int s = baseEightToTen(size);
		if(s != 0) {
			int skip = (s - (s%512)) / 512;
			if(s%512 != 0) skip++;
			lseek(tar_fd, 512 * skip, SEEK_CUR); 
		}
		read(tar_fd, (void *) buf, 512);
	}
	return 0;
}

/**
 * Checks whether an entry exists in the archive and is a file.
 *
 * @param tar_fd A file descriptor pointing to the start of a tar archive file.
 * @param path A path to an entry in the archive.
 *
 * @return zero if no entry at the given path exists in the archive or the entry is not a file,
 *         any other value otherwise.
 */
int is_file(int tar_fd, char *path) {
	
	char buf[512];
	read(tar_fd, (void *) buf, 512);
	
	while(buf[0] != '\0') {
		if(buf[156] == '0' || buf[156] == '\0') {			
			int i = 0;
			int same_name = 1;
			while(path[i] != '\0') {
				if(path[i] != buf[i]) same_name = 0;
				i++;
			}
			if(buf[i] != '\0') same_name = 0;
			if(same_name == 1) return 1;
		}
		
		char size[13];
		for(int i = 0; i < 12; i++) {
			size[i] = buf[124 + i];
		}
		size[12] = '\0';
		int s = baseEightToTen(size);
		if(s != 0) {
			int skip = (s - (s%512)) / 512;
			if(s%512 != 0) skip++;
			lseek(tar_fd, 512 * skip, SEEK_CUR); 
		}
		read(tar_fd, (void *) buf, 512);
	}
	return 0;
}

/**
 * Checks whether an entry exists in the archive and is a symlink.
 *
 * @param tar_fd A file descriptor pointing to the start of a tar archive file.
 * @param path A path to an entry in the archive.
 * @return zero if no entry at the given path exists in the archive or the entry is not symlink,
 *         any other value otherwise.
 */
int is_symlink(int tar_fd, char *path) {
    
    char buf[512];
	read(tar_fd, (void *) buf, 512);
	
	while(buf[0] != '\0') {
		if(buf[156] == '2') {			
			int i = 0;
			int same_name = 1;
			while(path[i] != '\0') {
				if(path[i] != buf[i]) same_name = 0;
				i++;
			}
			if(buf[i] != '\0') same_name = 0;
			if(same_name == 1) return 1;
		}
		
		char size[13];
		for(int i = 0; i < 12; i++) {
			size[i] = buf[124 + i];
		}
		size[12] = '\0';
		int s = baseEightToTen(size);
		if(s != 0) {
			int skip = (s - (s%512)) / 512;
			if(s%512 != 0) skip++;
			lseek(tar_fd, 512 * skip, SEEK_CUR); 
		}
		read(tar_fd, (void *) buf, 512);
	}
	return 0;
}


/**
 * Lists the entries at a given path in the archive.
 *
 * @param tar_fd A file descriptor pointing to the start of a tar archive file.
 * @param path A path to an entry in the archive. If the entry is a symlink, it must be resolved to its linked-to entry.
 * @param entries An array of char arrays, each one is long enough to contain a tar entry
 * @param no_entries An in-out argument.
 *                   The caller set it to the number of entry in entries.
 *                   The callee set it to the number of entry listed.
 *
 * @return zero if no directory at the given path exists in the archive,
 *         any other value otherwise.
 */
int list(int tar_fd, char *path, char **entries, size_t *no_entries) {
    return 0;
}

/**
 * Reads a file at a given path in the archive.
 *
 * @param tar_fd A file descriptor pointing to the start of a tar archive file.
 * @param path A path to an entry in the archive to read from.  If the entry is a symlink, it must be resolved to its linked-to entry.
 * @param offset An offset in the file from which to start reading from, zero indicates the start of the file.
 * @param dest A destination buffer to read the given file into.
 * @param len An in-out argument.
 *            The caller set it to the size of dest.
 *            The callee set it to the number of bytes written to dest.
 *
 * @return -1 if no entry at the given path exists in the archive or the entry is not a file,
 *         -2 if the offset is outside the file total length,
 *         zero if the file was read in its entirety into the destination buffer,
 *         a positive value if the file was partially read, representing the remaining bytes left to be read.
 *
 */
ssize_t read_file(int tar_fd, char *path, size_t offset, uint8_t *dest, size_t *len) {
    return 0;
}
