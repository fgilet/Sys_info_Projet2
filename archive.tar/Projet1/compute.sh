#!/bin/bash

echo "Threads, t1, t2, t3, t4, t5" > Data/phil_time.csv

for t in 2 3 4 5 6 7 8
do 
        echo "Timing with $t philosophes" > /dev/stdout
        T1=$((/usr/bin/time -f "%e" ./Part1/philosophe $t 2>&1) | tail -n 1)
        echo "Time 1 : $T1" > /dev/stdout
        T2=$((/usr/bin/time -f "%e" ./Part1/philosophe $t 2>&1) | tail -n 1)
        echo "Time 2 : $T2" > /dev/stdout
        T3=$((/usr/bin/time -f "%e" ./Part1/philosophe $t 2>&1) | tail -n 1)
        echo "Time 3 : $T3" > /dev/stdout
        T4=$((/usr/bin/time -f "%e" ./Part1/philosophe $t 2>&1) | tail -n 1)
        echo "Time 4 : $T4" > /dev/stdout
        T5=$((/usr/bin/time -f "%e" ./Part1/philosophe $t 2>&1) | tail -n 1) 
        echo "Time 5 : $T5" > /dev/stdout

        echo "$t,$T1,$T2,$T3,$T4,$T5" >> Data/phil_time.csv
done

echo "Threads, t1, t2, t3, t4, t5" > Data/pc_time.csv

for t in 2 3 4 5 6 7 8
do
        if [ $(($t%2)) -eq 0 ]
        then 
                P=$(($t/2))
                C=$(($t/2))
        else
                P=$((($t-1)/2))
                C=$((($t+1)/2))
        fi 
        echo "Timing with $P producers and $C consumers" > /dev/stdout
        T1=$((/usr/bin/time -f "%e" ./Part1/producer_consumer $P $C 2>&1) | tail -n 1)
        echo "Time 1 : $T1" > /dev/stdout
        T2=$((/usr/bin/time -f "%e" ./Part1/producer_consumer $P $C 2>&1) | tail -n 1)
        echo "Time 2 : $T2" > /dev/stdout
        T3=$((/usr/bin/time -f "%e" ./Part1/producer_consumer $P $C 2>&1) | tail -n 1)
        echo "Time 3 : $T3" > /dev/stdout
        T4=$((/usr/bin/time -f "%e" ./Part1/producer_consumer $P $C 2>&1) | tail -n 1)
        echo "Time 4 : $T4" > /dev/stdout
        T5=$((/usr/bin/time -f "%e" ./Part1/producer_consumer $P $C 2>&1) | tail -n 1) 
        echo "Time 5 : $T5" > /dev/stdout

        echo "$t,$T1,$T2,$T3,$T4,$T5" >> Data/pc_time.csv
done

echo "Threads, t1, t2, t3, t4, t5" > Data/wr_time.csv

for t in 1 2 3 4 5 6 7 8
do
        if [ $(($t%2)) -eq 0 ]
        then 
                W=$(($t/2))
                R=$(($t/2))
        else
                W=$((($t-1)/2))
                R=$((($t+1)/2))
        fi 
 
        echo "Timing with $W writers and $R readers" > /dev/stdout
        T1=$((/usr/bin/time -f "%e" ./Part1/writer_reader $W $R 2>&1) | tail -n 1)
        echo "Time 1 : $T1" > /dev/stdout
        T2=$((/usr/bin/time -f "%e" ./Part1/writer_reader $W $R 2>&1) | tail -n 1)
        echo "Time 2 : $T2" > /dev/stdout
        T3=$((/usr/bin/time -f "%e" ./Part1/writer_reader $W $R 2>&1) | tail -n 1)
        echo "Time 3 : $T3" > /dev/stdout
        T4=$((/usr/bin/time -f "%e" ./Part1/writer_reader $W $R 2>&1) | tail -n 1)
        echo "Time 4 : $T4" > /dev/stdout
        T5=$((/usr/bin/time -f "%e" ./Part1/writer_reader $W $R 2>&1) | tail -n 1) 
        echo "Time 5 : $T5" > /dev/stdout

        echo "$t,$T1,$T2,$T3,$T4,$T5" >> Data/wr_time.csv
done

echo "Threads, t1, t2, t3, t4, t5" > Data/test_and_set_time.csv

for t in 1 2 3 4 5 6 7 8
do 
        echo "Timing test_and_set with $t threads" > /dev/stdout
        T1=$((/usr/bin/time -f "%e" ./Part2/test_tas $t 2>&1) | tail -n 1)
        echo "Time 1 : $T1" > /dev/stdout
        T2=$((/usr/bin/time -f "%e" ./Part2/test_tas $t 2>&1) | tail -n 1)
        echo "Time 2 : $T2" > /dev/stdout
        T3=$((/usr/bin/time -f "%e" ./Part2/test_tas $t 2>&1) | tail -n 1)
        echo "Time 3 : $T3" > /dev/stdout
        T4=$((/usr/bin/time -f "%e" ./Part2/test_tas $t 2>&1) | tail -n 1)
        echo "Time 4 : $T4" > /dev/stdout
        T5=$((/usr/bin/time -f "%e" ./Part2/test_tas $t 2>&1) | tail -n 1) 
        echo "Time 5 : $T5" > /dev/stdout

        echo "$t,$T1,$T2,$T3,$T4,$T5" >> Data/test_and_set_time.csv
done

echo "Threads, t1, t2, t3, t4, t5" > Data/test_and_test_and_set_time.csv

for t in 1 2 3 4 5 6 7 8
do 
        echo "Timing test_and_test_and_set with $t threads" > /dev/stdout
        T1=$((/usr/bin/time -f "%e" ./Part2/test_tatas $t 2>&1) | tail -n 1)
        echo "Time 1 : $T1" > /dev/stdout
        T2=$((/usr/bin/time -f "%e" ./Part2/test_tatas $t 2>&1) | tail -n 1)
        echo "Time 2 : $T2" > /dev/stdout
        T3=$((/usr/bin/time -f "%e" ./Part2/test_tatas $t 2>&1) | tail -n 1)
        echo "Time 3 : $T3" > /dev/stdout
        T4=$((/usr/bin/time -f "%e" ./Part2/test_tatas $t 2>&1) | tail -n 1)
        echo "Time 4 : $T4" > /dev/stdout
        T5=$((/usr/bin/time -f "%e" ./Part2/test_tatas $t 2>&1) | tail -n 1) 
        echo "Time 5 : $T5" > /dev/stdout

        echo "$t,$T1,$T2,$T3,$T4,$T5" >> Data/test_and_test_and_set_time.csv
done

echo "Threads, t1, t2, t3, t4, t5" > Data/backoff_test_and_test_and_set_time.csv

for t in 1 2 3 4 5 6 7 8
do 
        echo "Timing backoff_test_and_test_and_set with $t threads" > /dev/stdout
        T1=$((/usr/bin/time -f "%e" ./Part2/test_btatas $t 2>&1) | tail -n 1)
        echo "Time 1 : $T1" > /dev/stdout
        T2=$((/usr/bin/time -f "%e" ./Part2/test_btatas $t 2>&1) | tail -n 1)
        echo "Time 2 : $T2" > /dev/stdout
        T3=$((/usr/bin/time -f "%e" ./Part2/test_btatas $t 2>&1) | tail -n 1)
        echo "Time 3 : $T3" > /dev/stdout
        T4=$((/usr/bin/time -f "%e" ./Part2/test_btatas $t 2>&1) | tail -n 1)
        echo "Time 4 : $T4" > /dev/stdout
        T5=$((/usr/bin/time -f "%e" ./Part2/test_btatas $t 2>&1) | tail -n 1) 
        echo "Time 5 : $T5" > /dev/stdout

        echo "$t,$T1,$T2,$T3,$T4,$T5" >> Data/backoff_test_and_test_and_set_time.csv
done


echo "Threads, t1, t2, t3, t4, t5" > Data/my_phil_time.csv

for t in 2 3 4 5 6 7 8
do 
        echo "Timing with $t philosophes (with custom TATAS)" > /dev/stdout
        T1=$((/usr/bin/time -f "%e" ./Part2/my_philosophe $t 2>&1) | tail -n 1)
        echo "Time 1 : $T1" > /dev/stdout
        T2=$((/usr/bin/time -f "%e" ./Part2/my_philosophe $t 2>&1) | tail -n 1)
        echo "Time 2 : $T2" > /dev/stdout
        T3=$((/usr/bin/time -f "%e" ./Part2/my_philosophe $t 2>&1) | tail -n 1)
        echo "Time 3 : $T3" > /dev/stdout
        T4=$((/usr/bin/time -f "%e" ./Part2/my_philosophe $t 2>&1) | tail -n 1)
        echo "Time 4 : $T4" > /dev/stdout
        T5=$((/usr/bin/time -f "%e" ./Part2/my_philosophe $t 2>&1) | tail -n 1) 
        echo "Time 5 : $T5" > /dev/stdout

        echo "$t,$T1,$T2,$T3,$T4,$T5" >> Data/my_phil_time.csv
done

echo "Threads, t1, t2, t3, t4, t5" > Data/my_pc_time.csv

for t in  2 3 4 5 6 7 8
do
        if [ $(($t%2)) -eq 0 ]
        then 
                P=$(($t/2))
                C=$(($t/2))
        else
                P=$((($t-1)/2))
                C=$((($t+1)/2))
        fi 
        echo "Timing with $P producers and $C consumers (with custom TATAS)" > /dev/stdout
        T1=$((/usr/bin/time -f "%e" ./Part2/my_producer_consumer $P $C 2>&1) | tail -n 1)
        echo "Time 1 : $T1" > /dev/stdout
        T2=$((/usr/bin/time -f "%e" ./Part2/my_producer_consumer $P $C 2>&1) | tail -n 1)
        echo "Time 2 : $T2" > /dev/stdout
        T3=$((/usr/bin/time -f "%e" ./Part2/my_producer_consumer $P $C 2>&1) | tail -n 1)
        echo "Time 3 : $T3" > /dev/stdout
        T4=$((/usr/bin/time -f "%e" ./Part2/my_producer_consumer $P $C 2>&1) | tail -n 1)
        echo "Time 4 : $T4" > /dev/stdout
        T5=$((/usr/bin/time -f "%e" ./Part2/my_producer_consumer $P $C 2>&1) | tail -n 1) 
        echo "Time 5 : $T5" > /dev/stdout

        echo "$t,$T1,$T2,$T3,$T4,$T5" >> Data/my_pc_time.csv
done

echo "Threads, t1, t2, t3, t4, t5" > Data/my_wr_time.csv

for t in 1 2 3 4 5 6 7 8
do
        if [ $(($t%2)) -eq 0 ]
        then 
                W=$(($t/2))
                R=$(($t/2))
        else
                W=$((($t-1)/2))
                R=$((($t+1)/2))
        fi 
 
        echo "Timing with $W writers and $R readers (with custom TATAS)" > /dev/stdout
        T1=$((/usr/bin/time -f "%e" ./Part2/my_writer_reader $W $R 2>&1) | tail -n 1)
        echo "Time 1 : $T1" > /dev/stdout
        T2=$((/usr/bin/time -f "%e" ./Part2/my_writer_reader $W $R 2>&1) | tail -n 1)
        echo "Time 2 : $T2" > /dev/stdout
        T3=$((/usr/bin/time -f "%e" ./Part2/my_writer_reader $W $R 2>&1) | tail -n 1)
        echo "Time 3 : $T3" > /dev/stdout
        T4=$((/usr/bin/time -f "%e" ./Part2/my_writer_reader $W $R 2>&1) | tail -n 1)
        echo "Time 4 : $T4" > /dev/stdout
        T5=$((/usr/bin/time -f "%e" ./Part2/my_writer_reader $W $R 2>&1) | tail -n 1) 
        echo "Time 5 : $T5" > /dev/stdout

        echo "$t,$T1,$T2,$T3,$T4,$T5" >> Data/my_wr_time.csv
done
