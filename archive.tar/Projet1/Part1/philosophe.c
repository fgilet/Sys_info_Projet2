#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>

pthread_t *phil;
pthread_mutex_t *baguette;
int n; //nombre de philosophes

void* philosophe(void * arg) {
	//récupération de l'identifiant du philosophe
	int *id = (int *) arg; 
	int left = *id;
	int right = (left + 1) % n;

	for(int i = 0; i < 1000000; i++) {
		//pour éviter que chaque philosophe tienne la baguette à sa gauche et attende celle à sa droite, le philosophe avec l'identifiant le plus élevé tente de prendre les baguettes dans l'ordre inverse
		if(left < right) {
			pthread_mutex_lock(&baguette[left]);
			pthread_mutex_lock(&baguette[right]);
		} else {
			pthread_mutex_lock(&baguette[right]);
			pthread_mutex_lock(&baguette[left]);
		} 
		//mange
		//libération des baguettes
		pthread_mutex_unlock(&baguette[left]);
		pthread_mutex_unlock(&baguette[right]); 
	}
	free(id);
	return NULL;
}

int main(int argc, char *argv[]) {

	//récupération du nombre de philosophes
	char *p;
	n = strtol(argv[1], &p, 10); 
	
	//allocation de la mémoire
	phil = (pthread_t *) malloc(n * sizeof(pthread_t));
	baguette = (pthread_mutex_t *) malloc(n * sizeof(pthread_mutex_t));
	
	//initialisation des mutex
	for(int i = 0; i < n; i++) {
		if(pthread_mutex_init(&(baguette[i]), NULL) != 0) return -1;
	}
	
	//création des threads
	for(int i = 0; i < n; i++) {
		int *id = (int *) malloc(sizeof(int));
		*id = i;
		if(pthread_create(&(phil[i]), NULL, &philosophe, (void *) id)) return -2;
	}
	
	//attente que tous les philosophes aient finis
	for(int i = n - 1; i >= 0; i--) {
		if(pthread_join(phil[i], NULL) != 0) return -3;
	}
	
	//destruction des mutex
	for(int i = n - 1; i >= 0; i--) {
		if(pthread_mutex_destroy(&(baguette[i])) != 0) return -4;
	}
	
	//libération de la mémoire
	free(phil);
	free(baguette);
	
	return 0;
}
