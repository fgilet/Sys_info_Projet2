#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <semaphore.h>

#define N 8 //taille du buffer

pthread_mutex_t mutex;
sem_t full;
sem_t empty;
int buffer[N];
int writeNext; //indice de la prochaine case du buffer où écrire
int readNext; //indice de la prochaine case du buffer à lire
int prodTOT; //total d'éléments produits
int conTOT; //total d'éléments consommés

/*
afin de vérifier que les éléments consommés correspondent aux éléments produits,
les producteurs écrivent dans le buffer ainsi que dans un fichier texte,
les consommateurs lisent dans le buffer et écrivent ce qu'il ont lu dans un autre fichier texte,
après exécution les deux fichiers contiennent les mêmes éléments (mais pas forcément dans le même ordre)
*/
FILE *f1; //fichier d'écriture du producteur
FILE *f2; //fichier d'écriture du consommateur

void* producer(void * arg) {
	int item;
	while(prodTOT < 1024) {
		//entier aléatoire
		item = rand(); 
		//simulation du temps de production
		while(rand() > RAND_MAX/10000); 
		//vérification qu'il y a de la place dans le buffer
		sem_wait(&empty); 
		//un seul thread peut accèder au buffer à la fois
		pthread_mutex_lock(&mutex); 
		
		//si le nombre de productions total a été atteint depuis l'entrée dans la boucle, libération du lock et de la sémaphore et terminaison du thread
		if(prodTOT >= 1024) { 
			pthread_mutex_unlock(&mutex);
			sem_post(&empty);
			return NULL;
		}
		
		//écriture dans le buffer
		buffer[writeNext] = item; 
		//écriture dans le fichier texte
		fprintf(f1, "%d\n", item); 
		//mise à jour de l'indice d'écriture
		writeNext = (writeNext + 1)%N; 
		//mise à jour du compteur de production
		prodTOT++; 
		
		//libération de la section critique et signalement d'un nouvel élément produit
		pthread_mutex_unlock(&mutex);
		sem_post(&full); 
	}
	return NULL;
}

void* consumer(void *arg) {
	while(conTOT < 1024) {
		//vérification qu'il y a un élément à consommer
		sem_wait(&full); 
		//un seul thread peut accèder au buffer à la fois
		pthread_mutex_lock(&mutex); 
		
		//si le nombre de consommations total a été atteint depuis l'entrée dans la boucle, libération du lock et de la sémaphore et terminaison du thread
		if(conTOT >= 1024) { 
			sem_post(&full);
			pthread_mutex_unlock(&mutex);
			return NULL;
		}
		
		//écriture dans le fichier texte depuis le buffer
		fprintf(f2, "%d\n", buffer[readNext]);  
		//mise à jour de l'indice de lecture
		readNext = (readNext + 1)%N; 
		//mise à jour du compteur de consommation
		conTOT++; 
		
		//libération de la section critique et signalement d'un nouvel élément produit
		pthread_mutex_unlock(&mutex); 
		sem_post(&empty); 
		
		//simulation du traitement de données
		while(rand() > RAND_MAX/10000); 
	}
	//nécéssaire pour éviter un deadlock si jamais plusieurs consomateurs attendaient la dernière valeur 
	sem_post(&full); 
	return NULL;
}

int main(int argc, char *argv[]) {

	//ouverture des fichiers textes
	f1 = fopen("Part1/produced.txt", "w");
	f2 = fopen("Part1/consumed.txt", "w"); 

	//récupération du nombre de producteurs-consommateurs
	char *p;
	int nProd = strtol(argv[1], &p, 10);
	int nCon = strtol(argv[2], &p, 10);
	
	writeNext = 0;
	readNext = 0;
	
	//initialisation du mutex
	if(pthread_mutex_init(&mutex, NULL) != 0) return -1;
	
	//initialisation des sémaphores
	if(sem_init(&empty, 0, N) != 0) return -2;
	if(sem_init(&full, 0, 0) != 0) return -3;
	
	//création des threads
	pthread_t producers[nProd];
	for(int i = 0; i < nProd; i++) {
		if(pthread_create(&(producers[i]), NULL, &producer, NULL) != 0) return -4; 
	}
	
	pthread_t consumers[nCon];
	for(int i = 0; i < nCon; i++) {
		if(pthread_create(&(consumers[i]), NULL, &consumer, NULL) != 0) return -5; 
	}
	
	//attente des threads en cours
	for(int i = nProd - 1; i >= 0; i--) {
		if(pthread_join(producers[i], NULL) != 0) return -6;
	} 
	
	for(int i = nCon - 1; i >= 0; i--) {
		if(pthread_join(consumers[i], NULL) != 0) return -7;
	} 
	
	//destruction du mutex
	if(pthread_mutex_destroy(&mutex) != 0) return -8;
	
	//fermeture des fichiers textes
	fclose(f1);
	fclose(f2);
	
	return 0;
}
