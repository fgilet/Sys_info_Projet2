#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

sem_t writing;
sem_t reading;

pthread_mutex_t mutex;

int readerCount; //nombre de lecteurs dans la section critique

int writeTOT;
int readTOT;

void* write(void * arg) {
	while(writeTOT < 640) {
		//vérification qu'aucun écrivain n'est occupé
		sem_wait(&writing);
		//vérification qu'aucun lecteur n'est occupé
		sem_wait(&reading);
	
		if(writeTOT < 640) {
			//simulation du temps d'écriture
			while(rand() > RAND_MAX/10000);
			writeTOT++;
		} 
		
		sem_post(&reading);
		sem_post(&writing);
	}
	return NULL;
}

void* read(void * arg){
	while(readTOT < 2560) {
		//vérification qu'aucun écrivain n'est occupé
		sem_wait(&writing); 
		
		//verrouillage des compteurs et signalement de la présence de lecteurs
		pthread_mutex_lock(&mutex);
		if(readerCount == 0) {
			sem_wait(&reading);
		}
		readerCount++;
		pthread_mutex_unlock(&mutex);
		//libération d'une sémaphore pour éviter le problème de famine
		sem_post(&writing);
	
		//vérification que le nombre de lectures n'a pas été atteint depuis l'entrée dans la boucle, sinon correction des compteurs, remise des locks et sémaphores et terminaison du thread
		pthread_mutex_lock(&mutex);
		if(readTOT >= 2560) {
			readerCount--;
			if(readerCount == 0) sem_post(&reading);
			pthread_mutex_unlock(&mutex);
			return NULL;
		}
		pthread_mutex_unlock(&mutex);
		
		//simulation d'une lecture
		while(rand() > RAND_MAX/10000);
		
		//mise à jour des compteurs et libération du lock et sémaphore
		pthread_mutex_lock(&mutex);
		readTOT++;	
		readerCount--;
		if(readerCount == 0) {
			sem_post(&reading);
		}
		pthread_mutex_unlock(&mutex);
	}
	return NULL;
}

int main(int argc, char *argv[]) {

	//récupération du nombre de producteurs-consommateurs
	char *p;
	int nWriter = strtol(argv[1], &p, 10);
	int nReader = strtol(argv[2], &p, 10);
	
	readerCount = 0;
	writeTOT = 0;
	readTOT = 0;
	
	//initialisation des sémaphores et du mutex
	if(sem_init(&writing, 0, 1) != 0) return -1;
	if(sem_init(&reading, 0, 1) != 0) return -2;
	if(pthread_mutex_init(&mutex, NULL) != 0) return -3;
	
	pthread_t writers[nWriter];
	pthread_t readers[nReader];
	
	//création des threads
	for(int i = 0; i < nWriter; i++) {
		if(pthread_create(&(writers[i]), NULL, &write, NULL) != 0) return -4;
	}
	
	for(int i = 0; i < nReader; i++) {
		if(pthread_create(&(readers[i]), NULL, &read, NULL) != 0) return -5;
	}
	
	//attente des threads en cours d'exécution
	for(int i = nWriter - 1; i >= 0; i--) {
		if(pthread_join(writers[i], NULL) != 0) return -6;
	}
	
	for(int i = nReader - 1; i >= 0; i--) {
		if(pthread_join(readers[i], NULL) != 0) return -7;
	}
	
	//destruction du mutex
	if(pthread_mutex_destroy(&mutex) != 0) return -8;
	
	return 0;
}
