#ifndef SEM
#define SEM

typedef struct sem_t {
	Tatas_t lock;
	int tokens;
} Sem_t;

void init_sem(Sem_t *sem, int n);

void wait(Sem_t *sem);

void post(Sem_t *sem);
#endif
