#ifndef BACKOFF_TEST_AND_TEST_AND_SET
#define BACKOFF_TEST_AND_TEST_AND_SET

typedef struct btatas_t {
	int l;
} Btatas_t;

int T_MIN;
int T_MAX;

void init_BTATAS(Btatas_t *lock);

void lock_BTATAS(Btatas_t *lock);

void unlock_BTATAS(Btatas_t *lock);
#endif
