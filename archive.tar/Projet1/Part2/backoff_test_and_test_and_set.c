#include <stdio.h>
#include <unistd.h>

typedef struct btatas_t {
	int l; //0 si ouvert, 1 sinon
} Btatas_t;

//temps d'attentes maximum et minimum, T_MIN est en réalité la moitié du temps d'attente minimum car il est toujours multiplié par 2 avant l'appel de sleep(), ceci permet de tester le verru immédiatemment après le sleep()
int T_MIN = 0.001;
int T_MAX = 0.5;

void init_BTATAS(Btatas_t *lock) {
	//initialisation du verrou sur 0
	(*lock).l = 0;
}

void lock_BTATAS(Btatas_t *lock) {
	int val = 1;
	int t;
	do {
		t = T_MIN;
		//attente que le verrou soit ouvert
		while((*lock).l == 1) {
			//le temps d'attente est doublé tant qu'il reste inférieur à T_MAX
			if(t < 2*T_MAX) t = t * 2;
			sleep(t);
		}
		//opération atomique d'échange de valeur entre val et le verrou
		asm("xchg %0, %1" : "+q" (val), "+m" ((*lock).l));
		//si val == 0 alors alors verrou a été correctement mis à 1 et le thread est le seul à pouvoir entrer dans la section critique
	} while(val == 1);
}

void unlock_BTATAS(Btatas_t *lock) {
	//remise de la valeur du verrou à 0
	(*lock).l = 0;
}
