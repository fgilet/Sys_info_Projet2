#ifndef TEST_AND_TEST_AND_SET
#define TEST_AND_TEST_AND_SET

typedef struct tatas_t {
	int l;
} Tatas_t;

void init_TATAS(Tatas_t *lock);

void lock_TATAS(Tatas_t *lock);

void unlock_TATAS(Tatas_t *lock);
#endif
