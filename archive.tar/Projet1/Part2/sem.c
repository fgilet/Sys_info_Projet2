#include <stdio.h>
#include "test_and_test_and_set.h"

typedef struct sem_t {
	//une sémaphore est un structure de données contenant une valeur tokens, correspondant au nombre de threads que la sémaphore peut encore laisser passer, et un verrou pour empêcher des modifications concurrentes du compteur de tokens
	Tatas_t lock;
	int tokens;
} Sem_t;

int init_sem(Sem_t *sem, int n) {
	//initialisation du verrou de la sémaphore
	init_TATAS(&((*sem).lock));
	//initialisation du compteur de tokens
	(*sem).tokens = n;
}

void wait(Sem_t *sem) {
	while(1) {
		//attente que le compteur de tokens soit non-nul
		while((*sem).tokens == 0){}
		//verrouillage du compteur
		lock_TATAS(&((*sem).lock));
		//si il y a un token libre, il est pris et la fonction wait return
		if((*sem).tokens > 0) {
			(*sem).tokens = (*sem).tokens - 1;
			unlock_TATAS(&((*sem).lock));
			return;
		}
		//sinon le compteur est déverouillé et on recommence
		unlock_TATAS(&((*sem).lock));
	} 
}

void post(Sem_t *sem) {
	//verrouillage du compteur et restitution d'un token
	lock_TATAS(&((*sem).lock));
	(*sem).tokens = (*sem).tokens + 1;
	unlock_TATAS(&((*sem).lock));
}
