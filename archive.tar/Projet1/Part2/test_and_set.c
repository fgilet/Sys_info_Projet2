#include <stdio.h>

typedef struct tas_t {
	int l; //0 si ouvert, 1 sinon
} Tas_t;

void init_TAS(Tas_t *lock) {
	//initialisation du verrou sur 0
	(*lock).l = 0;
}

void lock_TAS(Tas_t *lock) {
	int val = 1;
	do {
		//opération atomique d'échange de valeur entre val et le verrou
		asm("xchg %0, %1" : "+q" (val), "+m" ((*lock).l));
		//si val == 0 alors alors verrou a été correctement mis à 1 et le thread est le seul à pouvoir entrer dans la section critique
	} while(val == 1);
}

void unlock_TAS(Tas_t *lock) {
	//remise de la valeur du verrou à 0
	(*lock).l = 0;
}

