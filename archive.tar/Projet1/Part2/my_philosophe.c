#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include "test_and_test_and_set.h"

pthread_t *phil;
Tatas_t *baguette; //sémaphore test-and-test-and-set
int n; //nombre de philosophes

void* philosophe(void * arg) {
	//récupération de l'identifiant du philosophe
	int *id = (int *) arg; 
	int left = *id;
	int right = (left + 1) % n;

	for(int i = 0; i < 1000000; i++) {
		//pour éviter que chaque philosophe tienne la baguette à sa gauche et attende celle à sa droite, le philosophe avec l'identifiant le plus élevé tente de prendre les baguettes dans l'ordre inverse
		if(left < right) {
			lock_TATAS(&baguette[left]);
			lock_TATAS(&baguette[right]);
		} else {
			lock_TATAS(&baguette[right]);
			lock_TATAS(&baguette[left]);
		}
		//mange
		//libération des baguettes
		unlock_TATAS(&baguette[left]);
		unlock_TATAS(&baguette[right]);
	}
	//libération de la mémoire allouée sur la heap
	free(id);
	return NULL;
}

int main(int argc, char *argv[]) {

	//récupération du nombre de philosophes
	char *p;
	n = strtol(argv[1], &p, 10);
	
	//allocation de la mémoire
	phil = (pthread_t *) malloc(n * sizeof(pthread_t));
	baguette = (Tatas_t *) malloc(n * sizeof(Tatas_t));
	
	//initialisation des mutex test-and-test-and-set
	for(int i = 0; i < n; i++) {
		init_TATAS(&(baguette[i]));
	}
	
	//création des threads
	for(int i = 0; i < n; i++) {
		int *id = (int *) malloc(sizeof(int));
		*id = i;
		if(pthread_create(&(phil[i]), NULL, &philosophe, (void *) id) != 0) return -1;
	}
	
	//attente que tous les philosophes aient finis
	for(int i = n - 1; i >= 0; i--) {
		if(pthread_join(phil[i], NULL) != 0) return -2;
	}
	
	//libération de la mémoire
	free(phil);
	free(baguette);
	return 0;
}
