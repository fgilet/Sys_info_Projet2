#ifndef TEST_AND_SET
#define TEST_AND_SET

typedef struct tas_t {
	int l;
} Tas_t;

void init_TAS(Tas_t *lock);

void lock_TAS(Tas_t *lock);

void unlock_TAS(Tas_t *lock);
#endif
