#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include "test_and_test_and_set.h"
#include "sem.h"

#define N 8

Tatas_t lock;
Sem_t full;
Sem_t empty;
int buffer[N];
int writeNext; //indice de la prochaine case du buffer où écrire
int readNext; //indice de la prochaine case du buffer à lire
int prodTOT;  //total d'éléments produits
int conTOT; //total d'éléments consommés

/*
afin de vérifier que les éléments consommés correspondent aux éléments produits,
les producteurs écrivent dans le buffer ainsi que dans un fichier texte,
les consommateurs lisent dans le buffer et écrivent dans un autre fichier texte,
après exécution les deux fichiers contiennent les mêmes éléments (mais pas forcément dans le même ordre)
*/
FILE *f1; //fichier d'écriture du producteur
FILE *f2; //fichier d'écriture du consommateur

void* producer(void * arg) {
	int item;
	while(prodTOT < 1024) {
		//entier aléatoire
		item = rand();
		//simulation du temps de production
		while(rand() > RAND_MAX/10000);
		//vérification qu'il y a de la place dans le buffer
		wait(&empty);
		//un seul thread peut accèder au buffer à la fois
		lock_TATAS(&lock);
		
		//si le nombre de productions total a été atteint depuis l'entrée dans la boucle, libération du lock et de la sémaphore et terminaison du thread
		if(prodTOT >= 1024) {
			unlock_TATAS(&lock);
			return NULL;
		}
		
		//écriture dans le buffer
		buffer[writeNext] = item;
		//écriture dans le fichier texte
		fprintf(f1, "%d\n", item);
		//mise à jour de l'indice d'écriture
		writeNext = (writeNext + 1)%N;
		//mise à jour du compteur de production
		prodTOT++;
		
		//libération de la section critique et signalement d'un nouvel élément produit
		unlock_TATAS(&lock);
		post(&full);
	}
	return NULL;
}

void* consumer(void *arg) {
	while(conTOT < 1024) {
		//vérification qu'il y a un élément à consommer
		wait(&full);
		//un seul thread peut accèder au buffer à la fois
		lock_TATAS(&lock);
		
		//si le nombre de consommations total a été atteint depuis l'entrée dans la boucle, libération du lock et de la sémaphore et terminaison du thread
		if(conTOT >= 1024) {
			post(&full);
			unlock_TATAS(&lock);
			return NULL;
		}
		
		//écriture dans le fichier texte depuis le buffer
		fprintf(f2, "%d\n", buffer[readNext]);
		//mise à jour de l'indice de lecture
		readNext = (readNext + 1)%N;
		//mise à jour du compteur de consommation
		conTOT++;
		//libération de la section critique et signalement d'un nouvel élément produit
		unlock_TATAS(&lock);
		post(&empty);
		
		//simulation du traitement de données
		while(rand() > RAND_MAX/10000);
	}
	//nécéssaire pour éviter un deadlock si jamais plusieurs consomateurs attendaient la dernière valeur 
	post(&full); 
	return NULL;
}

int main(int argc, char *argv[]) {

	//ouverture des fichiers textes
	f1 = fopen("Part2/produced.txt", "w");
	f2 = fopen("Part2/consumed.txt", "w"); 

	//récupération du nombre de producteurs-consommateurs
	char *p;
	int nProd = strtol(argv[1], &p, 10);
	int nCon = strtol(argv[2], &p, 10);
	
	writeNext = 0;
	readNext = 0;
	
	//initialisation du mutex
	init_TATAS(&lock);
	
	//initialisation des sémaphores
	init_sem(&empty, N);
	init_sem(&full, 0);
	
	//création des threads
	pthread_t producers[nProd];
	for(int i = 0; i < nProd; i++) {
		if(pthread_create(&(producers[i]), NULL, &producer, NULL) != 0) return -1; 
	}
	
	pthread_t consumers[nCon];
	for(int i = 0; i < nCon; i++) {
		if(pthread_create(&(consumers[i]), NULL, &consumer, NULL) != 0) return -2; 
	}
	
	//attente des threads en cours
	for(int i = nProd - 1; i >= 0; i--) {
		if(pthread_join(producers[i], NULL) != 0) return -3;
	} 
	
	for(int i = nCon - 1; i >= 0; i--) {
		if(pthread_join(consumers[i], NULL) != 0) return -4;
	} 	
	
	//fermeture des fichiers textes
	fclose(f1);
	fclose(f2);
	return 0;
}
