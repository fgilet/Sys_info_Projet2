#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include "test_and_test_and_set.h"
#include "sem.h"

Sem_t writing;
Sem_t reading;

Tatas_t lock;

int readerCount; //nombre de lecteurs dans la section critique

int writeTOT;
int readTOT;

void* write(void * arg) {
	while(writeTOT < 640) {
		//vérification qu'aucun écrivain n'est occupé
		wait(&writing);
		//vérification qu'aucun lecteur n'est occupé
		wait(&reading);
	
		if(writeTOT < 640) {
			//simulation du temps d'écriture
			while(rand() > RAND_MAX/10000);
			writeTOT++;
		} 
		
		post(&reading);
		post(&writing);
	}
	return NULL;
}

void* read(void * arg){
	while(readTOT < 2560) {
		//vérification qu'aucun écrivain n'est occupé
		wait(&writing); 
		
		//verrouillage des compteurs et signalement de la présence de lecteurs
		lock_TATAS(&lock);
		if(readerCount == 0) {
			wait(&reading);
		}
		readerCount++;
		unlock_TATAS(&lock);
		//libération d'une sémaphore pour éviter le problème de famine
		post(&writing);
	
		//vérification que le nombre de lectures n'a pas été atteint depuis l'entrée dans la boucle, sinon correction des compteurs, remise des locks et sémaphores et terminaison du thread
		lock_TATAS(&lock);
		if(readTOT >= 2560) {
			readerCount--;
			if(readerCount == 0) post(&reading);
			unlock_TATAS(&lock);
			return NULL;
		}
		unlock_TATAS(&lock);
		
		//simulation d'une lecture
		while(rand() > RAND_MAX/10000);
		
		//mise à jour des compteurs et libération du lock et sémaphore
		lock_TATAS(&lock);
		readTOT++;	
		readerCount--;
		if(readerCount == 0) {
			post(&reading);
		}
		unlock_TATAS(&lock);
	}
	return NULL;
}

int main(int argc, char *argv[]) {

	//récupération du nombre de producteurs-consommateurs
	char *p;
	int nWriter = strtol(argv[1], &p, 10);
	int nReader = strtol(argv[2], &p, 10);
	
	readerCount = 0;
	writeTOT = 0;
	readTOT = 0;
	
	//initialisation des sémaphores et du mutex
	init_sem(&writing, 1);
	init_sem(&reading, 1);
	init_TATAS(&lock);
	
	pthread_t writers[nWriter];
	pthread_t readers[nReader];
	
	//création des threads
	for(int i = 0; i < nWriter; i++) {
		if(pthread_create(&(writers[i]), NULL, &write, NULL) != 0) return -1;
	}
	
	for(int i = 0; i < nReader; i++) {
		if(pthread_create(&(readers[i]), NULL, &read, NULL) != 0) return -2;
	}
	
	//attente des threads en cours d'exécution
	for(int i = nWriter - 1; i >= 0; i--) {
		if(pthread_join(writers[i], NULL) != 0) return -3;
	}
	
	for(int i = nReader - 1; i >= 0; i--) {
		if(pthread_join(readers[i], NULL) != 0) return -4;
	}
	
	return 0;
}
