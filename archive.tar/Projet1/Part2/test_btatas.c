#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "backoff_test_and_test_and_set.h"

int n; //nombre de threads
Btatas_t lock; //verrou test-and-test-and-set

void *inc(void *arg) {
	int i = 0;
	while(i < 6400/n) {
		//verrouillage de la section critique
		lock_BTATAS(&lock);
		//simulation d'opérations
		while(rand() > RAND_MAX/10000);
		//déverrouillage
		unlock_BTATAS(&lock);
		i++;
	}
}

int main(int argc, char *argv[]) {

	//récupération du nombre de threads
	char *p;
	n = strtol(argv[1], &p, 10);
	
	//initialisation du verrou backoff-test-and-test-and-set
	init_BTATAS(&lock);
	
	//création des threads
	pthread_t threads[n];
	for(int i = 0; i < n; i++) {
		if(pthread_create(&(threads[i]), NULL, &inc, NULL) != 0) return -1;
	}
	
	//attente des threads en cours d'exécution
	for(int i = 0; i < n; i++) {
		if(pthread_join(threads[i], NULL) != 0) return -2;
	}
}
