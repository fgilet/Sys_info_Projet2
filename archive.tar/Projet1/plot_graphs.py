import numpy as np
import csv
from matplotlib import pyplot as plt
from pathlib import Path

#lectures des temps d'exécutions des fichiers .csv et sauvegarde dans des matrices numpy

t_philosophes = np.empty([7, 5])

f = open("Data/phil_time.csv", "r")
with f:
	reader = csv.reader(f)
	next(reader)
	i = 0
	for row in reader:
		t_philosophes[i] = row[1:]
		i = i + 1

t_pc = np.empty([7, 5])

f = open("Data/pc_time.csv", "r")
with f:
	reader = csv.reader(f)
	next(reader)
	i = 0
	for row in reader:
		t_pc[i] = row[1:]
		i = i + 1
		
t_wr = np.empty([8, 5])

f = open("Data/wr_time.csv", "r")
with f:
	reader = csv.reader(f)
	next(reader)
	i = 0
	for row in reader:
		t_wr[i] = row[1:]
		i = i + 1

t_tas = np.empty([8, 5])

f = open("Data/test_and_set_time.csv", "r")
with f:
	reader = csv.reader(f)
	next(reader)
	i = 0
	for row in reader:
		t_tas[i] = row[1:]
		i = i + 1

t_tatas = np.empty([8, 5])
		
f = open("Data/test_and_test_and_set_time.csv", "r")
with f:
	reader = csv.reader(f)
	next(reader)
	i = 0
	for row in reader:
		t_tatas[i] = row[1:]
		i = i + 1
		
t_btatas = np.empty([8, 5])
		
f = open("Data/backoff_test_and_test_and_set_time.csv", "r")
with f:
	reader = csv.reader(f)
	next(reader)
	i = 0
	for row in reader:
		t_btatas[i] = row[1:]
		i = i + 1
		
t_my_philosophes = np.empty([7, 5])

f = open("Data/my_phil_time.csv", "r")
with f:
	reader = csv.reader(f)
	next(reader)
	i = 0
	for row in reader:
		t_my_philosophes[i] = row[1:]
		i = i + 1

t_my_pc = np.empty([7, 5])

f = open("Data/my_pc_time.csv", "r")
with f:
	reader = csv.reader(f)
	next(reader)
	i = 0
	for row in reader:
		t_my_pc[i] = row[1:]
		i = i + 1
		
t_my_wr = np.empty([8, 5])

f = open("Data/my_wr_time.csv", "r")
with f:
	reader = csv.reader(f)
	next(reader)
	i = 0
	for row in reader:
		t_my_wr[i] = row[1:]
		i = i + 1

#initialisation des vecteurs de moyennes et écarts types

means_philosophes = np.empty(7)
means_pc = np.empty(7)
means_wr = np.empty(8)
means_tas = np.empty(8)
means_tatas = np.empty(8)
means_btatas = np.empty(8)
means_my_philosophes = np.empty(7)
means_my_pc = np.empty(7)
means_my_wr = np.empty(8)

std_philosophes = np.empty(7)
std_pc = np.empty(7)
std_wr = np.empty(8)
std_tas = np.empty(8)
std_tatas = np.empty(8)
std_btatas = np.empty(8)
std_my_philosophes = np.empty(7)
std_my_pc = np.empty(7)
std_my_wr = np.empty(8)

#calcul des moyennes et écarts types

for i in range(0, 7):
	means_philosophes[i] = np.mean(t_philosophes[i])
	means_pc[i] = np.mean(t_pc[i])
	means_wr[i] = np.mean(t_wr[i])
	means_tas[i] = np.mean(t_tas[i])
	means_tatas[i] = np.mean(t_tatas[i])
	means_btatas[i] = np.mean(t_btatas[i])
	means_my_philosophes[i] = np.mean(t_my_philosophes[i])
	means_my_pc[i] = np.mean(t_my_pc[i])
	means_my_wr[i] = np.mean(t_my_wr[i])
	
	std_philosophes[i] = np.std(t_philosophes[i])
	std_pc[i] = np.std(t_pc[i])
	std_wr[i] = np.std(t_wr[i])
	std_tas[i] = np.std(t_tas[i])
	std_tatas[i] = np.std(t_tatas[i])
	std_btatas[i] = np.std(t_btatas[i])
	std_my_philosophes[i] = np.std(t_my_philosophes[i])
	std_my_pc[i] = np.std(t_my_pc[i])
	std_my_wr[i] = np.std(t_my_wr[i])

means_wr[7] = np.mean(t_wr[7])
means_my_wr[7] = np.mean(t_my_wr[7])
means_tas[7] = np.mean(t_tas[7])
means_tatas[7] = np.mean(t_tatas[7])
means_btatas[7] = np.mean(t_btatas[7])
std_wr[7] = np.std(t_wr[7])
std_my_wr[7] = np.std(t_my_wr[7])
std_tas[7] = np.std(t_tas[7])
std_tatas[7] = np.std(t_tatas[7])
std_btatas[7] = np.std(t_btatas[7])

#traçage des graphes

plt.figure()		
plt.errorbar([2, 3, 4, 5, 6, 7, 8], means_philosophes, std_philosophes, color = 'red', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.legend(['avec la librairie posix'])
plt.xlabel('Threads')
plt.ylabel('Temps [s]')
plt.ylim(ymin=0)
plt.savefig('Graphs/philosophes.pdf')

plt.figure()	
plt.errorbar([2, 3, 4, 5, 6, 7, 8], means_pc, std_pc, color = 'red', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.legend(['avec la librairie posix'])
plt.xlabel('Threads')
plt.ylabel('Temps [s]')
plt.ylim(ymin=0)
plt.savefig('Graphs/producers_consumers.pdf')

plt.figure()	
plt.errorbar([1, 2, 3, 4, 5, 6, 7, 8], means_wr, std_wr, color = 'red', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.legend(['avec la librairie posix'])
plt.xlabel('Threads')
plt.ylabel('Temps [s]')
plt.ylim(ymin=0)
plt.savefig('Graphs/writers_readers.pdf')

plt.figure()
plt.errorbar([1, 2, 3, 4, 5, 6, 7, 8], means_tas, std_tas, color = 'red', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.errorbar([1, 2, 3, 4, 5, 6, 7, 8], means_tatas, std_tatas, color = 'orange', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.errorbar([1, 2, 3, 4, 5, 6, 7, 8], means_btatas, std_btatas, color = 'green', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.legend(['tes-and-set', 'test-and-test-and-set', 'backoff-test-and-test-and-set'])
plt.xlabel('Threads')
plt.ylabel('Temps [s]')
plt.ylim(ymin=0)
plt.savefig('Graphs/TASvsTATAS.pdf')

plt.figure()		
plt.errorbar([2, 3, 4, 5, 6, 7, 8], means_philosophes, std_philosophes, color = 'red', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.errorbar([2, 3, 4, 5, 6, 7, 8], means_my_philosophes, std_my_philosophes, color = 'blue', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.legend(['avec la librairie posix', 'avec l\'implémentation "maison"'])
plt.xlabel('Threads')
plt.ylabel('Temps [s]')
plt.ylim(ymin=0)
plt.savefig('Graphs/my_philosophes.pdf')

plt.figure()	
plt.errorbar([2, 3, 4, 5, 6, 7, 8], means_pc, std_pc, color = 'red', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.errorbar([2, 3, 4, 5, 6, 7, 8], means_my_pc, std_my_pc, color = 'blue', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.legend(['avec la librairie posix', 'avec l\'implémentation "maison"'])
plt.xlabel('Threads')
plt.ylabel('Temps [s]')
plt.ylim(ymin=0)
plt.savefig('Graphs/my_producers_consumers.pdf')

plt.figure()	
plt.errorbar([1, 2, 3, 4, 5, 6, 7, 8], means_wr, std_wr, color = 'red', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.errorbar([1, 2, 3, 4, 5, 6, 7, 8], means_my_wr, std_my_wr, color = 'blue', ecolor = 'black', elinewidth = 0.8, capsize = 2, barsabove = True)
plt.legend(['avec la librairie posix', 'avec l\'implémentation "maison"'])
plt.xlabel('Threads')
plt.ylabel('Temps [s]')
plt.ylim(ymin=0)
plt.xlim(xmax=9)
plt.savefig('Graphs/my_writers_readers.pdf')
		
